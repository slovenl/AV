package com.ywl5320.myplayer.listener;

/**
 * Created by yangw on 2018-2-28.
 */

public interface WlOnParparedListener {

    void onParpared();

}

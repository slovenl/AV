package com.ywl5320.myplayer.listener;

public interface WlOnRecordTimeListener {

    void onRecordTime(int recordTime);

}

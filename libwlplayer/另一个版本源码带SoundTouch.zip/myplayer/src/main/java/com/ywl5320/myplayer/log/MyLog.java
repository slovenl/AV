package com.ywl5320.myplayer.log;

import android.util.Log;

/**
 * Created by yangw on 2018-2-28.
 */

public class MyLog {

    public static void d(String msg)
    {
        Log.d("ywl5320", msg);
    }

}

package com.ywl5320.myplayer.listener;

import com.ywl5320.myplayer.WlTimeInfoBean;

/**
 * Created by yangw on 2018-3-25.
 */

public interface WlOnTimeInfoListener {

    void onTimeInfo(WlTimeInfoBean timeInfoBean);

}

package com.ywl5320.myplayer.listener;

public interface WlOnValumeDBListener {

    void onDbValue(int db);

}

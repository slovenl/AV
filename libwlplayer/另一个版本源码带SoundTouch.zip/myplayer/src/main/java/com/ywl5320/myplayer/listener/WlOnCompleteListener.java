package com.ywl5320.myplayer.listener;

/**
 * Created by yangw on 2018-3-25.
 */

public interface WlOnCompleteListener {

    void onComplete();

}

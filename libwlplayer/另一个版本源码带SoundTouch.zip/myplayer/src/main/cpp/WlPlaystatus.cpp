//
// Created by yangw on 2018-3-6.
//

#include "WlPlaystatus.h"

WlPlaystatus::WlPlaystatus() {
    exit = false;
}

WlPlaystatus::~WlPlaystatus() {

}

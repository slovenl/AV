package com.ywl5320.mymusic;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.ywl5320.myplayer.WlTimeInfoBean;
import com.ywl5320.myplayer.listener.WlOnParparedListener;
import com.ywl5320.myplayer.listener.WlOnPcmInfoListener;
import com.ywl5320.myplayer.listener.WlOnTimeInfoListener;
import com.ywl5320.myplayer.log.MyLog;
import com.ywl5320.myplayer.player.WlPlayer;

public class CutActivity extends AppCompatActivity{


    private WlPlayer wlPlayer;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cutaudio);
        wlPlayer = new WlPlayer();

        wlPlayer.setWlOnParparedListener(new WlOnParparedListener() {
            @Override
            public void onParpared() {
                wlPlayer.cutAudioPlay(20, 40, true);
            }
        });

        wlPlayer.setWlOnTimeInfoListener(new WlOnTimeInfoListener() {
            @Override
            public void onTimeInfo(WlTimeInfoBean timeInfoBean) {
                MyLog.d(timeInfoBean.toString());
            }
        });

        wlPlayer.setWlOnPcmInfoListener(new WlOnPcmInfoListener() {
            @Override
            public void onPcmInfo(byte[] buffer, int buffersize) {
                MyLog.d("buffersize: " + buffersize);
            }

            @Override
            public void onPcmRate(int samplerate, int bit, int channels) {
                MyLog.d("samplerate: " + samplerate);
            }
        });
    }

    public void cutaudio(View view) {

        wlPlayer.setSource("/mnt/shared/Other/林俊杰 - 爱不会绝迹.wav");
        wlPlayer.parpared();

    }
}
